=== Canos Framework ===
Author: Lollum
Version: 1.1.0
Requires at least: 4.1
Tested up to: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extra functionality for the Canos theme.

== Description ==

The Canos-Framework plugin extends the functionality of the Canos theme by adding support for count views, custom meta boxes, social and more. The plugin is required by the Canos theme because it will extend the theme to function as you see in the demo.

== Installation ==

This plugin can be installed directly from your site.

When you activate the Canos theme you see a warning asking you to install the required plugin. Just click on the 'Begin installing plugin' button.

== Frequently Asked Questions ==

= What is this plugin and why do I need it? =

The Canos-Framework plugin extends the functionality of the Canos theme by adding support for count views, custom meta boxes, social and more. The plugin is required by the Canos theme because it will extend the theme to function as you see in the demo.

= Can I use this plugin with other themes? =

The Canos-Framework plugin was developed to extend the functionality of the Canos theme specifically. It is not a plugin meant for use with other themes.

== Changelog ==

= v1.1.0 - Jul 23, 2015 =
* Security/escaping fixes.

= v1.0.0 - May 24, 2015 =
* First release.
